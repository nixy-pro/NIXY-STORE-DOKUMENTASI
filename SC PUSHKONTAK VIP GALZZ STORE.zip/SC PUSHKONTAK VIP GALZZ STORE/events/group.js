const logger = require("../utils/logger.js");

module.exports = async (reinbot, g) => {
  /*
  const { id, participants, action } = g;
  console.log(g);*/
  return;
};
