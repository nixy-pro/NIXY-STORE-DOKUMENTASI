module.exports = {
  name: "GALZZ STORE",
  version: "4.1.0",
  number: "",
  owner: {
    name: "GALZZ STORE",
    number: "6285942877643",
    whatsapp: "6285942877643@s.whatsapp.net",
    instagram: "https://www.instagram.com/galzz_98?igsh=MWZ0cDg4Zmdhbzdxcg==",
  },
  author: {
    name: "GALZZSTORE🔥",
    number: "6287812444884",
    whatsapp: "6287812444884@s.whatsapp.net",
    instagram: "https://www.instagram.com/galzz_98?igsh=MWZ0cDg4Zmdhbzdxcg==",
  },
  features: {
    antiCall: {
      status: true,
      block: false,
    },
    selfMode: true,
    broadcast: {
      text: "",
      limit: 9999,
      jeda: 10000,
      filterContact: false,
    },
    pushContacts: {
      text: "",
      limit: 9999,
      jeda: 10000,
      filterContacts: false,
    },
  },
};
