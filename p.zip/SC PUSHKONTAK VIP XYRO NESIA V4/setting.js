module.exports = {
  name: "XyroHost",
  version: "4.1.0",
  number: "",
  owner: {
    name: "XYRO NESIA",
    number: "6285788055721",
    whatsapp: "6285788055721@s.whatsapp.net",
    instagram: "https://instagram.com/xyronesiaidreal",
  },
  author: {
    name: "XyroHost",
    number: "6289603693479",
    whatsapp: "6289603693479@s.whatsapp.net",
    instagram: "https://instagram.com/thomvelz_real",
  },
  features: {
    antiCall: {
      status: true,
      block: false,
    },
    selfMode: true,
    broadcast: {
      text: "",
      limit: 9999,
      jeda: 7000,
      filterContact: false,
    },
    pushContacts: {
      text: "",
      limit: 9999,
      jeda: 7000,
      filterContacts: false,
    },
  },
};
