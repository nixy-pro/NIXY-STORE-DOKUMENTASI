const fs = require('fs')
const chalk = require('chalk')

global.owner = "6287735508842" //boleh diganti
global.namabot = "RDAG OFFC" // boleh diganti
global.botname = "" //jangan di isi
global.autoJoin = false
global.codeInvite = "Fa8u2v4MjSlGCZ2Nw1QYSS" // ga usah ganti
global.thumb = fs.readFileSync("./media/thumb.png") //ga usah ganti
global.sessionName = 'ramzyoffc' //Gausah diganti
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.packname = ""
global.author = "Sticker"

global.antilink = false

const mess = {
   wait: "TUNGGU BANG LAGI SAYA PROSES",
   success: "SUKSES",
   save: "*SUKSES SV OTOMATIS*",
   on: "SUDAH AKTIF", 
   off: "SUDAH OFF",
   query: {
       text: "TEKS NYA MANA KAK?",
       link: "LINK NYA MANA KAK?",
   },
   error: {
       fitur: "MOHON MAAF KAK FITUR EROR SILAHKAN CHAT DEVELOPER BOT AGAR BISA SEGERA DIPERBAIKI",
   },
   only: {
       group: "FITUR NYA CUMAN BISA DI DALEM GRUP YAH",
       private: "DI CHAT PRIBADI BANG BIAR BISA DI PAKE",
       owner: "GA USAH PAKE FITUR INI ASU LU BUKAN OWNER",
       admin: "GA USAH PAKE FITUR INI ASU LU BUKAN OWNER",
       badmin: "MAAF KAK KAYA NYA KAKAK TIDAK BISA MENGGUNAKAN FITUR INI DI KARENAKAN BOT BUKAN ADMIN GROUP",
       premium: "MAAF KAMU BELUM JADI USER PREMIUM UNTUK MENJADI USER PREMIUM SILAHKAN BELI KE OWNER DENGAN CARA KETIK .owner",
   }
}

global.mess = mess
//=================================================//
//Gausah Juga
global.limitawal = {
    premium: "Infinity",
    free: 100
}
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})